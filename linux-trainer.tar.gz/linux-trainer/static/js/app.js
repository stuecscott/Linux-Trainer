// Linux Trainer - frontend interactions
// (kept simple: vanilla JS, no build step)

document.addEventListener("DOMContentLoaded", () => {
  setupQuiz();
  setupCompleteToggle();
  setupLabToggle();
});

// ---------- quiz ----------

function setupQuiz() {
  const quiz = document.querySelector(".quiz");
  if (!quiz) return;

  const submitBtn = quiz.querySelector(".btn-submit");
  const retryBtn  = quiz.querySelector(".btn-retry");
  const scoreEl   = quiz.querySelector(".quiz-score");
  const lessonId  = quiz.dataset.lessonId;

  submitBtn?.addEventListener("click", () => {
    const questions = quiz.querySelectorAll(".quiz-question");
    let score = 0;
    let total = questions.length;

    questions.forEach((q) => {
      const correct = parseInt(q.dataset.correct, 10);
      const optsList = q.querySelector(".quiz-options");
      const labels = optsList.querySelectorAll("label");
      const selected = q.querySelector("input[type=radio]:checked");

      optsList.classList.add("answered");
      labels.forEach((lbl, idx) => {
        if (idx === correct) lbl.classList.add("correct");
        else if (selected && parseInt(selected.value, 10) === idx) {
          lbl.classList.add("wrong");
        }
      });

      const expl = q.querySelector(".explanation");
      if (expl) expl.classList.add("visible");

      if (selected && parseInt(selected.value, 10) === correct) score += 1;
    });

    scoreEl.textContent = `Score: ${score} / ${total}`;
    submitBtn.style.display = "none";
    retryBtn.style.display = "inline-block";

    fetch("/api/quiz", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lesson_id: lessonId, score, total }),
    });
  });

  retryBtn?.addEventListener("click", () => {
    quiz.querySelectorAll(".quiz-options").forEach(o => {
      o.classList.remove("answered");
      o.querySelectorAll("label").forEach(l => {
        l.classList.remove("correct", "wrong");
      });
    });
    quiz.querySelectorAll("input[type=radio]").forEach(r => r.checked = false);
    quiz.querySelectorAll(".explanation").forEach(e => e.classList.remove("visible"));
    scoreEl.textContent = "";
    submitBtn.style.display = "inline-block";
    retryBtn.style.display = "none";
  });
}

// ---------- mark lesson complete ----------

function setupCompleteToggle() {
  const toggle = document.querySelector(".complete-toggle input");
  if (!toggle) return;

  toggle.addEventListener("change", async () => {
    const lessonId = toggle.dataset.lessonId;
    const url = toggle.checked ? "/api/complete" : "/api/uncomplete";
    await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ lesson_id: lessonId }),
    });
  });
}

// ---------- lab completion ----------

function setupLabToggle() {
  const lab = document.querySelector(".lab-toggle input");
  if (!lab) return;

  lab.addEventListener("change", async () => {
    await fetch("/api/lab", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: lab.dataset.key, done: lab.checked }),
    });
  });
}
