---
title: Coming Soon — Module 2 Preview
order: 1
estimate: 2 min
---

# Coming Soon

Module 2 will cover:

- **Wildcards** (`*`, `?`, `[abc]`) — filename patterns
- **Redirection** (`>`, `>>`, `<`) — capturing and feeding command output
- **Pipes** (`|`) — chaining commands together
- **`find` and `grep` in depth** — finding any file or text on the system fast
- **`xargs`** — running a command on every result of another command
- **`tar`, `gzip`, `zip`** — bundling and compressing

Add lessons to this module by creating files like `01-wildcards.md` in the `lessons/module-02-files/` directory and using the same format as Module 1's lessons.

> The trainer reads lessons from disk on each request, so you can add a lesson, refresh the browser, and see it.
