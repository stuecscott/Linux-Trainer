---
title: The Shell — What It Is, How to Read the Prompt
order: 3
estimate: 12 min
---

# The Shell — What It Is, How to Read the Prompt

You're staring at a prompt. Now what is that thing, exactly?

## A shell is a program that runs other programs

When you type `ls` and press Enter, your shell:

1. Reads what you typed.
2. Looks up the program named `ls` (it's at `/usr/bin/ls`).
3. Asks the kernel to start that program.
4. Captures the program's output and prints it back to your screen.
5. Returns to the prompt, ready for your next command.

That's it. The shell is a glorified loop: **read, look up, run, show output, repeat**.

The shell on Ubuntu (and most modern Linux) is called **bash** — the Bourne Again Shell. There are others (`zsh`, `fish`, `dash`), but bash is everywhere and what we'll use.

## Decoding the prompt

A typical prompt looks like:

```
learner@trainer01:~$
```

Reading left to right:

| Piece | Meaning |
|-------|---------|
| `learner` | Your username |
| `@` | Just a separator — read it as "at" |
| `trainer01` | The hostname (the machine's name) |
| `:` | Separator |
| `~` | Your **current directory**. The `~` is shorthand for "my home directory." |
| `$` | The prompt symbol. `$` means a regular user. `#` means root. |

If you `cd` into `/etc`, the prompt updates:

```
learner@trainer01:/etc$
```

Now `~` has been replaced with `/etc`, telling you exactly where you are.

> **Why this matters.** When you copy commands from the internet, watch for `$` vs `#`. A `#` prompt means the example expects to be run as root. Don't paste the prompt itself — copy only what comes after.

## Two essential keys you'll use constantly

**Tab** — autocompletes whatever you're typing. Half-type a command, hit Tab. Half-type a filename, hit Tab. If there's only one match, it fills it in. If there are several, hit Tab twice to see them.

**Up arrow** — recalls your previous command. Press it again for the one before that. This saves enormous amounts of typing.

A few more high-value keys:

| Keys | What it does |
|------|--------------|
| Ctrl + C | Cancel the current command. Use when you're stuck. |
| Ctrl + L | Clear the screen (same as `clear`). |
| Ctrl + A | Jump cursor to start of line. |
| Ctrl + E | Jump cursor to end of line. |
| Ctrl + R | Search through your command history. Type a fragment, hit Enter to use the match. |
| Ctrl + D | Sends "end of input." At an empty prompt, logs you out. |

## Your first three commands

Type each of these and read what they show:

```bash
whoami
hostname
pwd
```

- `whoami` — prints your username. Useful when you've sudo'd into something and forgot who you are.
- `hostname` — prints the machine's name.
- `pwd` — "print working directory." Tells you exactly where you are in the filesystem.

These three commands are completely safe. They read information; they don't change anything.

## The most useful command of all: `--help`

Almost every Linux command will explain itself if you ask politely:

```bash
ls --help
```

The output is dense, but it's the authoritative answer for what the command does and what flags it accepts. When you forget how to use something, `--help` is faster than searching the internet.

For more depth, there's `man`:

```bash
man ls
```

This opens the **manual page** in a pager. Press `q` to quit, `/word` then Enter to search for "word", `n` for next match. Manual pages are the canonical reference.

::lab::
**Goal:** Get comfortable reading the prompt and using key shortcuts.

In your VM, run each of these and observe the output:

```bash
whoami
hostname
pwd
echo "Hello, Linux"
```

Then practice these:

1. Type `whoa` and press **Tab**. It should complete to `whoami`.
2. Run `whoami`, then press **Up arrow** and Enter to repeat it.
3. Type `ls /e` and press **Tab**. It should complete to `ls /etc`.
4. Run `man ls`. Use `/option` then Enter to search for "option" inside the manual. Press `q` to quit.
5. Type a command and partway through press **Ctrl + A** to jump to the start, then **Ctrl + E** to jump back to the end.
6. Press **Ctrl + L** to clear the screen.

**Done when:** you can recall a previous command with the up arrow, autocomplete a filename with Tab, and quit a man page with `q` without panic.
::endlab::

::quiz::
Q: Your prompt looks like `root@trainer01:/etc#`. What does the `#` tell you?
- You're connected via SSH
- You're in the /etc directory
- You're currently running as the root user *
- The system is in maintenance mode
Explanation: `$` indicates a regular user; `#` indicates the root user. This is a strong visual cue that whatever you type next has full power over the system — be careful.

Q: You typed a long command and realize you need to fix something at the start. What's the fastest way?
- Hold left arrow until you get there
- Press Ctrl + A *
- Press Backspace until you reach it and retype
- Press Esc + Home
Explanation: Ctrl + A jumps to the beginning of the line. Ctrl + E jumps to the end. These work in most shell environments.

Q: What does `pwd` do?
- Lists files in the current directory
- Changes your password
- Prints the current working directory *
- Prints the previous working directory
Explanation: `pwd` stands for "print working directory" — it tells you exactly where you are in the filesystem. It does not change your password (`passwd` does that — easy mistake).
::endquiz::
