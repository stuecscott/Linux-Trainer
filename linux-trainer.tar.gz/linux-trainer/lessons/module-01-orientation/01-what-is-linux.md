---
title: What Linux Actually Is
order: 1
estimate: 8 min
---

# What Linux Actually Is

Before you type a single command, let's get the mental model right. People say "Linux" to mean three different things, and it pays to keep them separate.

## The kernel

At the very core, **Linux is a kernel** — the program that talks directly to your hardware. It schedules processes onto the CPU, manages memory, handles disks and networking, and brokers everything between your software and the metal. Linus Torvalds wrote the first version in 1991, and it's been collaboratively developed ever since.

The kernel by itself isn't very useful to a human. You can't *do* anything with just a kernel — there's nothing to type, no programs to run, no file manager.

## The userland

Around the kernel, you wrap a pile of programs that make the system actually useful — things like a shell to type into, a file manager, a text editor, networking tools, a package manager, and so on. Most of these come from a project called **GNU**, which is why purists will tell you it's "GNU/Linux."

## The distribution

A **distribution** (or "distro") is a packaged combination of the kernel + a chosen userland + a chosen way to install software + sensible defaults. It's what you actually download and install. Different distros make different choices:

| Family | Examples | Package tool | Where you'll see it |
|--------|----------|--------------|---------------------|
| Debian | Debian, Ubuntu, Mint, Pop!_OS | `apt` | Most home servers, cloud VMs |
| Red Hat | Fedora, RHEL, Rocky, AlmaLinux | `dnf` | Enterprise servers, scientific computing |
| Arch | Arch, Manjaro | `pacman` | Power users who like rolling releases |
| SUSE | openSUSE, SLES | `zypper` | European enterprise |

> **Why this trainer covers two families.** In the wild you'll bump into both Debian-style and Red Hat-style systems. The day-to-day commands (`ls`, `cd`, `cat`, etc.) are identical. What differs is **how you install software** and **a few system management details**. We'll flag the differences explicitly when they come up.

## What "running Linux" means in practice

When you boot your VirtualBox VM, here's roughly what happens:

1. The bootloader (usually GRUB) starts the kernel.
2. The kernel initializes hardware, mounts the root filesystem, and starts the first userspace process — usually `systemd`.
3. `systemd` brings up the rest of the system: networking, logging, login prompts, services.
4. You see a login prompt. After logging in, your **shell** starts and gives you a command prompt.

You'll spend nearly all your time at step 4 — talking to the shell.

## Two more vocabulary terms you'll see everywhere

- **Root** — the all-powerful administrator account, named `root`. Equivalent to "Administrator" on Windows but more so. The root user can delete *any* file on the system, including ones that will brick the OS. We avoid logging in as root directly.
- **sudo** — short for "superuser do." It lets a normal user temporarily run a single command with root privileges, after typing their password. This is the standard way to do administrative tasks safely.

::quiz::
Q: Strictly speaking, what is Linux?
- A complete operating system including a desktop environment
- An operating system kernel — the core program that talks to hardware *
- A package manager
- A type of shell
Explanation: "Linux" technically refers only to the kernel. A full operating system additionally needs a userland (commands, tools), and that combination packaged for installation is called a distribution.

Q: You're SSHing into a brand new server and need to install nginx. Which command would work on Ubuntu?
- pacman -S nginx
- dnf install nginx
- apt install nginx *
- nginx --install
Explanation: Ubuntu is in the Debian family, which uses `apt`. On Fedora/RHEL you'd use `dnf`. On Arch, `pacman`. The distro determines the package manager.

Q: What's the practical difference between root and sudo?
- They're identical aliases
- root is a Windows term, sudo is the Linux equivalent
- root is an account; sudo lets a normal user run one command as root *
- sudo is more dangerous than root
Explanation: `root` is a user account. `sudo` is a program that lets a regular user execute *individual* commands with root's permissions, which is safer because you stay logged in as yourself the rest of the time.
::endquiz::
