---
title: A Survival Kit of Commands
order: 5
estimate: 15 min
---

# A Survival Kit of Commands

You now know what the shell is and what the filesystem looks like. Here's a small set of commands that, between them, cover 80% of what you'll do day to day. We'll use the rest of the trainer to deepen each one — but you can functional with this set right away.

## Looking around

```bash
pwd                # where am I?
ls                 # what's in this directory?
ls -l              # ...with details
ls -la             # ...including hidden files
ls /etc            # ...in some other directory
```

The flags combine. `-l` is "long" (details). `-a` is "all" (include hidden). `-h` makes file sizes human-readable. So `ls -lah` is a common combination.

## Moving around

```bash
cd /etc            # go to /etc
cd ..              # up one level
cd                 # go home (same as cd ~)
cd -               # go back to where you just were
```

That last one — `cd -` — toggles between your last two directories. Very handy.

## Looking at files

```bash
cat notes.txt              # dump entire file to screen
less notes.txt             # scroll through it (q to quit)
head notes.txt             # first 10 lines
tail notes.txt             # last 10 lines
tail -n 50 /var/log/syslog # last 50 lines of a log
tail -f /var/log/syslog    # follow live, ctrl+c to stop
```

`tail -f` is your best friend for watching logs while you're testing something — new lines appear as they're written.

## Creating, copying, moving, deleting

```bash
mkdir projects             # make a directory
mkdir -p a/b/c             # make nested directories at once
touch notes.txt            # create an empty file
cp notes.txt backup.txt    # copy
cp -r projects backup/     # copy a directory (-r = recursive)
mv notes.txt diary.txt     # rename (or move)
mv diary.txt ~/documents/  # move into another folder
rm backup.txt              # delete a file
rm -r projects             # delete a directory and everything in it
```

> **The `rm` warning.** There is **no Recycle Bin**. `rm` is final. Read what you typed before pressing Enter. Especially with `rm -r`. Especially if there's a wildcard. We'll cover safer patterns shortly.

## Searching and finding

```bash
find . -name "*.txt"            # find .txt files from here downward
grep "error" /var/log/syslog    # find lines containing "error"
grep -r "TODO" projects/        # search recursively in a folder
which ls                        # where is the `ls` program?
```

`find` searches by filename and metadata; `grep` searches *inside* files. You'll lean on grep heavily.

## Getting information

```bash
df -h          # disk space, human-readable
free -h        # memory usage
uptime         # how long the system has been up + load average
uname -a       # kernel and architecture info
ps aux         # processes currently running
top            # live process view (q to quit)
```

## Editing text

In a server VM with no GUI you need a terminal text editor. Two reasonable choices:

- **nano** — beginner-friendly. Commands shown at bottom of screen (`^X` means Ctrl+X).
- **vim** — extremely powerful, has a learning curve. Worth knowing eventually because it's installed *everywhere*.

For now, use nano:

```bash
nano notes.txt
```

To exit: **Ctrl + X**, then `Y` to save, then Enter.

## Running things as root

For commands that change the system, prefix with `sudo`:

```bash
sudo apt update            # Debian/Ubuntu
sudo dnf check-update      # Fedora/RHEL
```

It'll ask for your password the first time and remember briefly. If you mistype the password three times, sudo locks you out for a few seconds and complains in the system log.

## Distro-relevant differences in this lesson

The commands above (`ls`, `cd`, `cat`, `cp`, `mv`, `rm`, `find`, `grep`, `df`, `free`, etc.) are **identical on Debian/Ubuntu and Fedora/RHEL**. They've been standard since the 1970s. The first place you'll see distro differences is in the package manager (`apt` vs `dnf`), and in some service-management commands. We'll get there in Module 7.

## A simple safety habit

Before running anything destructive (`rm`, `mv`, `>`), get into the habit of running the **same command but with `ls`** first. For example, before:

```bash
rm -r old-project/
```

run:

```bash
ls -la old-project/
```

to confirm you're about to delete what you think you're about to delete. This habit will save you, repeatedly, forever.

::lab::
**Goal:** Use this whole set of commands together to do something real.

In your VM, run this little exercise. You'll create a project folder, put a file in it, search for stuff, and clean up.

```bash
cd ~
mkdir -p sandbox/notes
cd sandbox/notes

echo "first note"     > note1.txt
echo "second note"    > note2.txt
echo "todo: laundry"  > todo.txt
echo "todo: groceries" >> todo.txt

ls -la
cat note1.txt
cat todo.txt

# search inside files for the word "todo"
grep -i "todo" *.txt

# find all .txt files from sandbox down
cd ~/sandbox
find . -name "*.txt"

# move a file
mv notes/note1.txt notes/first.txt
ls notes/

# clean up
cd ~
rm -r sandbox          # be deliberate
ls
```

**Done when:** every command above runs cleanly with no errors, you understand what each line did, and the `sandbox/` directory is gone at the end.
::endlab::

::quiz::
Q: What does `ls -lah` show?
- All files including hidden, in long format, with sizes in human-readable units *
- All files, lowercase only, hidden
- Listing of /home directory
- Live updating list
Explanation: Each flag has a meaning. `-l` long format, `-a` all (includes hidden), `-h` human-readable sizes. Combining flags is standard.

Q: You want to follow the system log live as new entries arrive. Which command?
- cat /var/log/syslog
- watch /var/log/syslog
- tail -f /var/log/syslog *
- live /var/log/syslog
Explanation: `tail -f` ("follow") prints new lines as they're added to a file. Indispensable when watching logs while debugging something.

Q: You ran `rm important.txt` and immediately regretted it. What happens?
- It moves to a Trash folder you can recover from
- It's gone — there's no built-in undo *
- You can run `undo rm` to recover
- It's recoverable for 24 hours
Explanation: There is no Recycle Bin. `rm` is immediate and final on a normal filesystem. This is why the "ls before rm" habit matters.

Q: On a server with no graphical environment, you need to edit a config file. What's the right approach?
- Open a file manager
- Use a terminal editor like nano or vim *
- Edit it from another machine over the network
- Reinstall with the desktop edition
Explanation: Servers run headless on purpose — no GUI overhead. Terminal editors like `nano` (beginner-friendly) or `vim` (powerful) are the standard tools for this.
::endquiz::
