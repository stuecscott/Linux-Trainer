---
title: Setting Up Your Practice VM
order: 2
estimate: 20 min
---

# Setting Up Your Practice VM

You picked VirtualBox, which is exactly right for learning — it gives you a real, isolated Linux machine you can completely break and rebuild as many times as you want. Let's get one running.

We'll set up **two** small VMs over the course of this trainer: one Ubuntu (Debian family) and one Fedora (Red Hat family). For now, we just need the first one.

## Pick your ISO

For Module 1, install **Ubuntu Server 24.04 LTS**. We're using Server, not Desktop, on purpose:

- It's what your future home server will run.
- No graphical environment means you're forced to learn the shell.
- It's small (~3 GB) and fast.

Download from <https://ubuntu.com/download/server>.

> **Why LTS?** "Long-Term Support" releases get security updates for 5 years. For a server you don't want to constantly upgrade, LTS is the right default.

## Create the VM in VirtualBox

Settings that matter:

| Setting | Value | Why |
|---------|-------|-----|
| Type / Version | Linux / Ubuntu (64-bit) | Tells VBox which defaults to use |
| Memory | 2048 MB (2 GB) | Plenty for a learning VM |
| CPUs | 2 | Avoids sluggishness during installs |
| Disk | 25 GB, dynamically allocated | Only uses space as it fills |
| Network | NAT (default) | Lets the VM reach the internet |

After creating the VM, before starting it, attach the Ubuntu ISO:

> Settings → Storage → click the empty CD icon → choose your downloaded `.iso` file.

## Walk through the installer

The Ubuntu installer is a text-mode wizard. Most defaults are fine. Two things to be careful about:

1. **Server name** — pick something memorable. `trainer01` is fine.
2. **Your username** — short and lowercase is best. `learner` is fine for this course.
3. When asked about **OpenSSH server**, tick the box. We'll use it later.
4. Skip the "featured server snaps" page — we don't need any of those right now.

The install takes ~5 minutes. When it finishes, the installer will ask to reboot. Before letting it reboot, **remove the ISO** (Devices → Optical Drives → Remove disk from virtual drive). Otherwise it'll just boot back into the installer.

## First login

After reboot you'll see something like this:

```
Ubuntu 24.04 LTS trainer01 tty1

trainer01 login: _
```

Type your username, press Enter, type your password (it won't show — that's normal), press Enter. You're now staring at a prompt that looks roughly like:

```
learner@trainer01:~$
```

That prompt is your shell. It's where the rest of this trainer happens.

## Useful VirtualBox tips for learning

- **Snapshots are your superpower.** Take one named `clean install` right now (Machine → Take Snapshot). When you eventually break something, you can roll back in seconds and try again.
- **Right-Ctrl** releases your mouse from the VM window.
- **Right-Ctrl + F** toggles fullscreen.
- If text in the VM looks tiny, that's just VBox's default. Nothing to fix yet.

::lab::
**Goal:** Get a fresh Ubuntu Server VM running and reach a login prompt.

**Steps:**

1. Download Ubuntu Server 24.04 LTS from the link above.
2. In VirtualBox, click **New** and create a VM with the settings in the table.
3. Attach the ISO under Settings → Storage.
4. Start the VM and walk through the installer. When prompted, install OpenSSH server.
5. Remove the ISO and let the VM reboot.
6. Log in with the username and password you set.
7. **Take a snapshot named `clean install` immediately.** This is your safety net for the rest of the course.

**Done when:** you see a `username@hostname:~$` prompt, and you have a snapshot called `clean install` in VirtualBox.
::endlab::

::quiz::
Q: Why use Ubuntu Server instead of Ubuntu Desktop for this trainer?
- It's the only version that has a shell
- It's free, while Desktop is paid
- It mirrors what real servers run, and forces you to use the command line *
- It supports more hardware
Explanation: Ubuntu Desktop is also free and also has a shell. The reason for Server is that it has no graphical environment, so you can't fall back on point-and-click — and it's what you'll see on real servers and cloud VMs.

Q: What's the value of taking a VirtualBox snapshot?
- It speeds up the VM
- It lets you revert to a known-good state if you break the system *
- It backs up your files to the cloud
- It compresses the disk image
Explanation: Snapshots are local to VirtualBox and capture the entire VM state. When learning Linux, you *will* break things — snapshots let you experiment fearlessly because you can roll back instantly.
::endquiz::
