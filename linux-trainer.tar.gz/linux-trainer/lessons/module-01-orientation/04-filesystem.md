---
title: The Filesystem — A Guided Tour
order: 4
estimate: 12 min
---

# The Filesystem — A Guided Tour

In Linux, **everything is a file**. Your documents are files. Configuration is in files. Even hardware devices and running processes appear as files. Knowing the layout of where things live is half of being competent on the system.

## One tree, no drive letters

There are no `C:` and `D:` drives. There's a single root directory, written `/`, and everything else hangs off it. A path always reads from the root downward:

```
/home/learner/documents/notes.txt
```

That's: root → `home` → `learner` → `documents` → `notes.txt`.

When you connect a USB drive or a second hard disk, it gets **mounted** into the tree at some directory (commonly under `/mnt` or `/media`). After mounting, it just looks like another folder.

## The directories you'll meet over and over

Here are the ones worth memorizing right now. Don't worry about the others yet.

| Path | What lives there |
|------|------------------|
| `/` | The root of the whole filesystem |
| `/home/learner` | Your personal stuff. Your shell starts here. Shorthand: `~` |
| `/etc` | System-wide configuration files. Plain text, editable as root. |
| `/var` | Variable data — logs, mail spools, databases |
| `/var/log` | Log files. The first place you look when something is broken. |
| `/usr/bin` | Most installed programs (`ls`, `cat`, `grep`, etc.) live here |
| `/usr/local` | Stuff you install yourself, outside the package manager |
| `/tmp` | Temporary files. Wiped on reboot. Don't put anything important here. |
| `/root` | The root user's home directory (note: not under `/home`) |
| `/proc` and `/sys` | Virtual filesystems exposing kernel and process info |
| `/dev` | Hardware devices appear as files here (`/dev/sda`, `/dev/null`) |

> A surprising one for newcomers: **there is no Program Files**. Software isn't bundled into one folder per program. A package like `nginx` will scatter pieces across `/usr/bin`, `/etc/nginx`, `/var/log/nginx`, and `/var/lib/nginx`. The package manager keeps track of which file came from where so it can cleanly uninstall.

## Absolute vs relative paths

An **absolute path** starts with `/` and gives the full address from root:

```
/home/learner/notes.txt
```

A **relative path** is interpreted from wherever you currently are:

```
notes.txt        # in the current directory
docs/notes.txt   # one folder down
../other.txt     # one folder up
```

Two special directories you'll see in relative paths:

- `.` (a single dot) — the current directory
- `..` (two dots) — the parent directory

So `cd ..` means "go up one level." Useful constantly.

## The tilde, again

`~` always expands to the home directory of the current user. So:

```
~/notes.txt
```

is exactly the same as `/home/learner/notes.txt` (when logged in as `learner`).

## Files and directories are case-sensitive

`Notes.txt` and `notes.txt` are completely different files. Coming from Windows or macOS this is a common stumbling block. **Lowercase is the norm.** Save yourself headaches by sticking to lowercase filenames with hyphens or underscores instead of spaces.

## Hidden files start with a dot

A file or directory whose name begins with `.` is hidden from `ls` by default:

```
.bashrc          # bash configuration
.ssh/            # SSH keys and config
.config/         # user-specific app configs
```

To see them, use `ls -a`. We'll cover this properly next lesson.

::lab::
**Goal:** Walk around the filesystem and start building a mental map.

In your VM:

```bash
pwd                # confirm you're in /home/learner

cd /
ls                 # see the top-level directories

cd /etc
ls                 # see system config files
ls hostname        # there's a file just called "hostname"
cat hostname       # cat prints a file's contents

cd /var/log
ls                 # logs from various services

cd ~               # go home (~ expands to /home/learner)
pwd                # confirm
```

Then try the difference between absolute and relative paths:

```bash
cd /
cd home            # relative — you're now in /home
cd learner         # relative — now /home/learner
cd ..              # relative — back to /home
cd /etc            # absolute — jump straight to /etc
cd ~               # back home
```

**Done when:** you can predict what `pwd` will print after each `cd` command without running it first.
::endlab::

::quiz::
Q: Where do log files live by convention?
- /etc/logs
- /home/logs
- /var/log *
- /sys/log
Explanation: `/var/log` is where almost all system and service logs go. When something is broken, `cd /var/log` is usually your first move.

Q: You're in `/home/learner/projects/site`. You run `cd ../..`. Where are you now?
- /home
- /home/learner *
- /home/learner/projects
- /
Explanation: Each `..` goes up one level. From `/home/learner/projects/site`, one `..` is `projects`, another is `learner`. So `cd ../..` lands you in `/home/learner`.

Q: What's the difference between `notes.txt` and `Notes.txt` on Linux?
- They're the same file
- The capitalized one is treated as a system file
- They are two completely separate files *
- The lowercase one is a shortcut to the other
Explanation: Linux filesystems are case-sensitive. `notes.txt`, `Notes.txt`, and `NOTES.TXT` are three different files that can all exist in the same directory.

Q: You see a directory called `.ssh`. Why doesn't it show up in `ls`?
- It's encrypted
- Filenames starting with `.` are hidden by default *
- It's only visible to root
- It's a virtual directory
Explanation: A leading dot marks a file or directory as hidden. They show up with `ls -a`. This is just a convention — the filesystem itself doesn't treat them specially.
::endquiz::
