"""
Linux Trainer - a self-paced learning app for going from beginner
to mid-level Linux capable.

Run with:  python app.py
Then open: http://localhost:5000
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for
from pathlib import Path
import json
import re
import markdown
from datetime import datetime

app = Flask(__name__)

BASE_DIR = Path(__file__).parent
LESSONS_DIR = BASE_DIR / "lessons"
DATA_DIR = BASE_DIR / "data"
PROGRESS_FILE = DATA_DIR / "progress.json"

DATA_DIR.mkdir(exist_ok=True)


# ---------- progress storage ----------

def load_progress():
    """Load progress from disk, returning a sensible default if missing."""
    if not PROGRESS_FILE.exists():
        return {
            "completed_lessons": [],
            "quiz_attempts": {},
            "lab_completions": {},
            "started_at": datetime.now().isoformat(),
            "last_seen": None,
        }
    with open(PROGRESS_FILE, "r") as f:
        return json.load(f)


def save_progress(progress):
    progress["last_seen"] = datetime.now().isoformat()
    with open(PROGRESS_FILE, "w") as f:
        json.dump(progress, f, indent=2)


# ---------- lesson loading ----------

def parse_lesson_file(path):
    """
    Parse a lesson file. Lessons are Markdown with a YAML-like
    front-matter block at the top, plus optional ::quiz:: and ::lab::
    sections that we extract for interactive rendering.
    """
    text = path.read_text(encoding="utf-8")

    # front matter between --- lines
    meta = {}
    body = text
    fm_match = re.match(r"^---\n(.*?)\n---\n(.*)$", text, re.DOTALL)
    if fm_match:
        fm_text, body = fm_match.group(1), fm_match.group(2)
        for line in fm_text.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                meta[k.strip()] = v.strip()

    # extract quiz block
    quiz = None
    quiz_match = re.search(r"::quiz::\n(.*?)\n::endquiz::",
                           body, re.DOTALL)
    if quiz_match:
        quiz = parse_quiz(quiz_match.group(1))
        body = body.replace(quiz_match.group(0), "").strip()

    # extract lab block
    lab = None
    lab_match = re.search(r"::lab::\n(.*?)\n::endlab::",
                          body, re.DOTALL)
    if lab_match:
        lab = lab_match.group(1).strip()
        body = body.replace(lab_match.group(0), "").strip()

    return {
        "id": path.stem,
        "module": path.parent.name,
        "title": meta.get("title", path.stem),
        "order": int(meta.get("order", 0)),
        "estimate": meta.get("estimate", "10 min"),
        "body_md": body.strip(),
        "body_html": markdown.markdown(
            body.strip(),
            extensions=["fenced_code", "codehilite", "tables", "attr_list"],
            extension_configs={"codehilite": {"css_class": "code"}},
        ),
        "quiz": quiz,
        "lab": lab,
        "lab_html": markdown.markdown(
            lab, extensions=["fenced_code", "codehilite", "attr_list"],
            extension_configs={"codehilite": {"css_class": "code"}},
        ) if lab else None,
    }


def parse_quiz(text):
    """
    Parse a quiz block. Format:

      Q: question text
      - option one
      - option two *
      - option three
      Explanation: why the answer is what it is.

    A * marks the correct option.
    """
    questions = []
    blocks = [b.strip() for b in text.split("\n\n") if b.strip()]
    for block in blocks:
        lines = block.splitlines()
        question_text = ""
        options = []
        correct = None
        explanation = ""
        for line in lines:
            line = line.strip()
            if line.startswith("Q:"):
                question_text = line[2:].strip()
            elif line.startswith("- "):
                opt = line[2:].strip()
                if opt.endswith("*"):
                    opt = opt[:-1].strip()
                    correct = len(options)
                options.append(opt)
            elif line.startswith("Explanation:"):
                explanation = line[len("Explanation:"):].strip()
        if question_text and options:
            questions.append({
                "question": question_text,
                "options": options,
                "correct": correct,
                "explanation": explanation,
            })
    return questions


def load_curriculum():
    """Walk the lessons directory and return the full curriculum tree."""
    modules = []
    if not LESSONS_DIR.exists():
        return modules

    for module_dir in sorted(LESSONS_DIR.iterdir()):
        if not module_dir.is_dir():
            continue

        module_meta_file = module_dir / "module.json"
        if module_meta_file.exists():
            module_meta = json.loads(module_meta_file.read_text())
        else:
            module_meta = {"title": module_dir.name, "order": 0}

        lessons = []
        for lf in module_dir.glob("*.md"):
            lessons.append(parse_lesson_file(lf))
        lessons.sort(key=lambda x: x["order"])

        modules.append({
            "id": module_dir.name,
            "title": module_meta.get("title", module_dir.name),
            "description": module_meta.get("description", ""),
            "order": module_meta.get("order", 0),
            "lessons": lessons,
        })

    modules.sort(key=lambda x: x["order"])
    return modules


# ---------- routes ----------

@app.route("/")
def home():
    curriculum = load_curriculum()
    progress = load_progress()
    completed = set(progress["completed_lessons"])

    total_lessons = sum(len(m["lessons"]) for m in curriculum)
    pct = (len(completed) / total_lessons * 100) if total_lessons else 0

    # mark which lessons are done & figure out next-up
    next_up = None
    for m in curriculum:
        for l in m["lessons"]:
            l["done"] = l["id"] in completed
            if not l["done"] and next_up is None:
                next_up = (m, l)

    return render_template(
        "home.html",
        curriculum=curriculum,
        completed_count=len(completed),
        total_count=total_lessons,
        progress_pct=round(pct),
        next_up=next_up,
    )


@app.route("/lesson/<module_id>/<lesson_id>")
def lesson(module_id, lesson_id):
    curriculum = load_curriculum()
    progress = load_progress()

    # find current lesson + neighbors for prev/next nav
    flat = []
    for m in curriculum:
        for l in m["lessons"]:
            flat.append((m, l))

    idx = next((i for i, (m, l) in enumerate(flat)
                if m["id"] == module_id and l["id"] == lesson_id), None)
    if idx is None:
        return "Lesson not found", 404

    module, current = flat[idx]
    prev_lesson = flat[idx - 1] if idx > 0 else None
    next_lesson = flat[idx + 1] if idx < len(flat) - 1 else None

    return render_template(
        "lesson.html",
        module=module,
        lesson=current,
        prev_lesson=prev_lesson,
        next_lesson=next_lesson,
        is_complete=current["id"] in progress["completed_lessons"],
        lab_done=progress["lab_completions"].get(
            f"{module_id}/{lesson_id}", False),
    )


@app.route("/api/complete", methods=["POST"])
def mark_complete():
    data = request.json or {}
    lesson_id = data.get("lesson_id")
    if not lesson_id:
        return jsonify({"error": "missing lesson_id"}), 400

    progress = load_progress()
    if lesson_id not in progress["completed_lessons"]:
        progress["completed_lessons"].append(lesson_id)
    save_progress(progress)
    return jsonify({"ok": True})


@app.route("/api/uncomplete", methods=["POST"])
def mark_uncomplete():
    data = request.json or {}
    lesson_id = data.get("lesson_id")
    progress = load_progress()
    if lesson_id in progress["completed_lessons"]:
        progress["completed_lessons"].remove(lesson_id)
    save_progress(progress)
    return jsonify({"ok": True})


@app.route("/api/lab", methods=["POST"])
def mark_lab():
    data = request.json or {}
    key = data.get("key")
    done = bool(data.get("done"))
    progress = load_progress()
    progress["lab_completions"][key] = done
    save_progress(progress)
    return jsonify({"ok": True})


@app.route("/api/quiz", methods=["POST"])
def record_quiz():
    data = request.json or {}
    lesson_id = data.get("lesson_id")
    score = data.get("score")
    total = data.get("total")
    progress = load_progress()
    progress["quiz_attempts"].setdefault(lesson_id, []).append({
        "at": datetime.now().isoformat(),
        "score": score,
        "total": total,
    })
    save_progress(progress)
    return jsonify({"ok": True})


@app.route("/reset", methods=["POST"])
def reset_progress():
    if PROGRESS_FILE.exists():
        PROGRESS_FILE.unlink()
    return redirect(url_for("home"))


if __name__ == "__main__":
    print("\n  Linux Trainer running at http://localhost:5000\n")
    app.run(debug=True, port=5000)
